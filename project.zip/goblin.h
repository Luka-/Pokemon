#ifndef _GOBLIN__H_
#define _GOBLIN__H_
#include <iostream>
#include "enemies.h"

class goblin : public enemies {
	public :
		goblin(int,int);
		char getDesc();
};


#endif
