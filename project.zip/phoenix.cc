#include <iostream>
#include "phoenix.h"
using namespace std;

phoenix::phoenix(int row, int col) : enemies(row,col,50,35,20) {}

char phoenix::getDesc() {
	return 'X';
}
