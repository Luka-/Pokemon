#ifndef _ENEMIES__H_
#define _ENEMIES__H_
#include "living.h"
#include <iostream>

class enemies : public living {
	int distHor;
	int distVer;
	public :
		int tempAtk, tempDef;
		enemies(int,int,int,int,int);
		virtual char getDesc() = 0;
		int getDistHor();
		int getDistVer();
		void updateDistHor(int);
		void updateDistVer(int);
};

#endif
	
