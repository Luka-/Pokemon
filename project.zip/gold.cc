#include "gold.h"
#include <iostream>

gold::gold(int row, int col, int amount) : cell(row,col), amount(amount) {}

char gold::getDesc() {
	return 'G';
}
