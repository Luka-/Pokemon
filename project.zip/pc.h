#ifndef _PC__H_
#define _PC__H_
#include "living.h"
#include <string>

class pc : public living {
	public :
		int gold;
		bool mer;
		std::string inv[6];
		int invSize;
		int tempAtk, tempDef;
		pc(int,int, int, int, int);
		char getDesc();
		int gettempAtk();
		int gettempDef();
		int getGold();
		// Virtual stuff
		virtual void updateGold(int);
		virtual void setTmpAtk(int);
		virtual void setTmpDef(int);
		virtual std::string getRace();
};

#endif
