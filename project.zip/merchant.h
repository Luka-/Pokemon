#ifndef _MERCHANT__H_
#define _MERCHANT__H_
#include <iostream>
#include "enemies.h"

class merchant : public enemies {
	public :
		merchant(int,int);
		char getDesc();
};

#endif
