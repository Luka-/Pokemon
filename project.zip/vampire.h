#ifndef _VAMPIRE__H_
#define _VAMPIRE__H_
#include <iostream>
#include "enemies.h"

class vampire : public enemies {
	public :
		vampire(int,int);
		char getDesc();
};

#endif
