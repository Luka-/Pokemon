#ifndef __DWARF_H__
#define __DWARF_H__
#include <iostream>
#include "pc.h"
#include <string>

class dwarf : public pc {
	public:
	dwarf(int, int);
	void updateGold(int);
	void setTmpAtk(int);
	void setTmpDef(int);
	std::string getRace();
};

#endif
