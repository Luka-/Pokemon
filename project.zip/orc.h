#ifndef _ORC_H__
#define _ORC_H__
#include <iostream>
#include "pc.h"
#include <string>

class orc : public pc {
	public:
	orc(int, int);
	void updateGold(int);
	void setTmpAtk(int);
	void setTmpDef(int);
	std::string getRace();
};

#endif
