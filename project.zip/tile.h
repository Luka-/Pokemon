#ifndef _TILE__H_
#define _TILE__H_

#include <iostream>
#include <string>
#include "cell.h"

class tile : public cell {
	int flag;
	public :
		tile(int,int);
		char getDesc();
};

#endif
