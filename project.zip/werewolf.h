#ifndef _WEREWOLF__H_
#define _WEREWOLF__H_
#include <iostream>
#include "enemies.h"

class werewolf : public enemies {
	public :
		werewolf(int,int);
		char getDesc();
};


#endif
