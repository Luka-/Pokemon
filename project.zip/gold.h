#ifndef _GOLD__H_
#define _GOLD__H_
#include <iostream>

class gold : public cell {
	public :
	int amount;
	gold(int,int,int);
	char getDesc();
};


#endif
