#ifndef _LIVING__H_
#define _LIVING__H_
#include <iostream>
#include "cell.h"

class living : public cell {
	int HP;
	int Atk;
	int Def;
	
	public :
		cell* stand;
		living(int,int,int,int,int);
		int getHP();
		void updateHP(int num);
		int getDef();
		int getAtk();
		virtual char getDesc() = 0;
		void attack(living*);
};

#endif
