#include "orc.h"
#include <string>
using namespace std;

orc::orc(int row, int col) : pc(row, col, 180, 30, 25) {}

void orc::updateGold(int num) {
	gold += num/2;
}

void orc::setTmpAtk(int num)	{
	tempAtk += num;
}

void orc::setTmpDef(int num) {
	tempDef	+= num;
}

string orc::getRace() {
	return "Orc";
}
