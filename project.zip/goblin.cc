#include <iostream>
#include "goblin.h"
using namespace std;

goblin::goblin(int row, int col) : enemies(row,col,70,5,10) {}

char goblin::getDesc() {
	return 'N';
}
