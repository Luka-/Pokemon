#include <iostream>
#include "potion.h"
#include <string>
using namespace std;

potion::potion (int row, int col, string desc) : cell(row,col), desc(desc) {}

char potion::getDesc() {
	return 'P';
}

string potion::getType() {
	return desc;
}
