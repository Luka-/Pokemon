#ifndef _STAIR__H_
#define _STAIR__H_
#include "cell.h"

class stair : public cell {
	public :
		stair(int,int);
		char getDesc();
};

#endif
