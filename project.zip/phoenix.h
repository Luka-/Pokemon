#ifndef _PHOENIX__H_
#define _PHOENIX__H_
#include <iostream>
#include "enemies.h"

class phoenix : public enemies {
	public :
		phoenix(int,int);
		char getDesc();
};

#endif
