#include <iostream>
#include "stair.h"
using namespace std;

stair::stair(int row,int col) : cell(row,col) {} 

char stair::getDesc() {
	return '/';
}
