#ifndef _POTION__H_
#define _POTION__H_
#include <iostream>
#include "cell.h"
#include <string>

class potion : public cell {
	std::string desc;
	public :
		potion(int,int,std::string);
		char getDesc();
		std::string getType();
};
		
#endif
