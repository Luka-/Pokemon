#include <iostream>
#include "werewolf.h"
using namespace std;

werewolf::werewolf(int row, int col) : enemies(row,col,120,30,5) {}

char werewolf::getDesc() {
	return 'W';
}
