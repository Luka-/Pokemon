#ifndef _ELVES_H__
#define _ELVES_H__
#include <iostream>
#include "pc.h"
#include <string>

class elves : public pc {
	public:
	elves(int, int);
	void updateGold(int);
	void setTmpAtk(int);
	void setTmpDef(int);
	std::string getRace();
};

#endif
