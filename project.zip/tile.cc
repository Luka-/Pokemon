#include <iostream>
#include <string>
#include "tile.h"
using namespace std;

tile::tile(int row,int col) : cell(row,col) {
	flag = 1;
}

char tile::getDesc() {
	return '.';
}
