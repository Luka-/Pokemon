#ifndef _PASSAGE__H_
#define _PASSAGE__H_

#include <iostream>
#include <string>
#include "cell.h"

class passage : public cell {
	int flag;
	public : 
		passage(int,int);
		char getDesc();
};

#endif
