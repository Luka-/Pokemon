#include <iostream>
#include <string>
#include <cmath>
#include "board.h"
#include "orc.h"
#include "dwarf.h"
#include "elves.h"
using namespace std;


	

int main () {
	bool printIt = true;
	board* floor = new board(1);
	cout << endl;
	cout << "Choose your race wisely:" << endl;
	cout << "h-human e-elf d-dwarf o-orc" << endl << endl;
	char race;
	cin >> race;
	// Different classes
	
	int x, y;
	if (race == 'd') {
		x = floor->player->getRow();
		y = floor->player->getCol();
		delete floor->player;
		floor->player = new dwarf(x, y);
		floor->player->stand = new tile(x, y);
		floor->myfloor[x][y] = floor->player;
	}
	else if (race == 'e'){
		x = floor->player->getRow();
		y = floor->player->getCol();
		floor->player = NULL;
		delete floor->player;
		floor->player = new elves(x, y);
		floor->player->stand = new tile(x, y);
		floor->myfloor[x][y] = floor->player;
	}else if (race == 'o'){
		x = floor->player->getRow();
		y = floor->player->getCol();
		delete floor->player;
		floor->player = new orc(x, y);
		floor->player->stand = new tile(x, y);
		floor->myfloor[x][y] = floor->player;
	}
	
	
	
	//THE REPEATING PART STARTS HERE
	
	while (true) {
		
		if (printIt) floor->printboard();
		printIt = true;
		
		//If I am currently on stairs
		if (floor->player->stand->getDesc() == '/') {
			if (floor->floorNum == 8) {
				cout << endl << endl;
				cout << "Congratulations, you win!" << endl;
				cout << "Your score is: " << floor->player->getGold() << endl << endl;
				cout << "Press any character to quit" << endl;
				char z; cin >> z;
				break;
			}
			int num = floor->floorNum;
			if (floor != NULL) { delete floor; }
			floor = new board(num+1);
			floor->printboard();
		}
		
		//If I am currently standing on the potion
		if (floor->player->stand->getDesc() == 'P') {
			if (floor->player->invSize < 5) {
				potion* pot = dynamic_cast<potion*>(floor->player->stand);
				floor->player->inv[floor->player->invSize] = pot->getType();
				delete floor->player->stand;
				floor->player->stand = new tile(floor->player->getRow(),floor->player->getCol());
				floor->player->invSize++;
			}
		}  
			
		string s;
		cin >> s;
		
		if (s == "no" && floor->myfloor[floor->player->getRow()-1][floor->player->getCol()] != NULL) {
			floor->swapCell(floor->player,floor->myfloor[floor->player->getRow()-1][floor->player->getCol()]);
			floor->enemyAction();
		}
		else if (s == "so" && floor->myfloor[floor->player->getRow()+1][floor->player->getCol()] != NULL) {
			floor->swapCell(floor->player,floor->myfloor[floor->player->getRow()+1][floor->player->getCol()]);
			floor->enemyAction();
		}
		else if (s == "ea" && floor->myfloor[floor->player->getRow()][floor->player->getCol()+1] != NULL) {
			floor->swapCell(floor->player,floor->myfloor[floor->player->getRow()][floor->player->getCol()+1]);
			floor->enemyAction();
		}
		else if (s == "we" && floor->myfloor[floor->player->getRow()][floor->player->getCol()-1] != NULL) {
			floor->swapCell(floor->player,floor->myfloor[floor->player->getRow()][floor->player->getCol()-1]);
			floor->enemyAction();
		}
		else if (s == "ne" && floor->myfloor[floor->player->getRow()-1][floor->player->getCol()+1] != NULL) {
			floor->swapCell(floor->player,floor->myfloor[floor->player->getRow()-1][floor->player->getCol()+1]);
			floor->enemyAction();
		}
		else if (s == "nw" && floor->myfloor[floor->player->getRow()-1][floor->player->getCol()-1] != NULL) {
			floor->swapCell(floor->player,floor->myfloor[floor->player->getRow()-1][floor->player->getCol()-1]);
			floor->enemyAction();
		}
		else if (s == "se" && floor->myfloor[floor->player->getRow()+1][floor->player->getCol()+1] != NULL) {
			floor->swapCell(floor->player,floor->myfloor[floor->player->getRow()+1][floor->player->getCol()+1]);
			floor->enemyAction();
		}
		else if (s == "sw" && floor->myfloor[floor->player->getRow()+1][floor->player->getCol()-1] != NULL) {
			floor->swapCell(floor->player,floor->myfloor[floor->player->getRow()+1][floor->player->getCol()-1]);
			floor->enemyAction();
		}
		else if (s == "a") {
			cin >> s;
			if (s == "no" && floor->myfloor[floor->player->getRow()-1][floor->player->getCol()] != NULL) {
				char c = floor->myfloor[floor->player->getRow()-1][floor->player->getCol()]->getDesc();
				if (c == 'V' || c == 'W' || c == 'N' || c == 'T' || c == 'D' || c == 'X' || c == 'M') {
					living* life = dynamic_cast<living*>(floor->myfloor[floor->player->getRow()-1][floor->player->getCol()]);
					floor->player->attack(life);
					for (int i = 0; i < 20; i++) {
						if (floor->earr[i] != NULL) {
						if (floor->earr[i]->getHP() <= 0) {
							floor->myfloor[floor->player->getRow()-1][floor->player->getCol()] = new tile(floor->earr[i]->getRow(), floor->earr[i]->getCol());
							delete floor->earr[i];
							floor->earr[i] = NULL;
						}
						}
					}
					floor->enemyAction();
				}
			}
			else if (s == "so" && floor->myfloor[floor->player->getRow()+1][floor->player->getCol()] != NULL) {
				char c = floor->myfloor[floor->player->getRow()+1][floor->player->getCol()]->getDesc();
				if (c == 'V' || c == 'W' || c == 'N' || c == 'T' || c == 'D' || c == 'X' || c == 'M') {
					living* life = dynamic_cast<living*>(floor->myfloor[floor->player->getRow()+1][floor->player->getCol()]);
					floor->player->attack(life);
					for (int i = 0; i < 20; i++) {
						if (floor->earr[i] != NULL) {
						if (floor->earr[i]->getHP() <= 0) {
							floor->myfloor[floor->player->getRow()+1][floor->player->getCol()] = new tile(floor->earr[i]->getRow(), floor->earr[i]->getCol());
							delete floor->earr[i];
							floor->earr[i] = NULL;
						}
						}
					}
					floor->enemyAction();
				}
			}
			else if (s == "ea" && floor->myfloor[floor->player->getRow()][floor->player->getCol()+1] != NULL) {
				char c = floor->myfloor[floor->player->getRow()][floor->player->getCol()+1]->getDesc();
				if (c == 'V' || c == 'W' || c == 'N' || c == 'T' || c == 'D' || c == 'X' || c == 'M') {
					living* life = dynamic_cast<living*>(floor->myfloor[floor->player->getRow()][floor->player->getCol()+1]);
					floor->player->attack(life);
					for (int i = 0; i < 20; i++) {
						if (floor->earr[i] != NULL) {
						if (floor->earr[i]->getHP() <= 0) {
							floor->myfloor[floor->player->getRow()][floor->player->getCol()+1] = new tile(floor->earr[i]->getRow(), floor->earr[i]->getCol());
							delete floor->earr[i];
							floor->earr[i] = NULL;
						}
						}
					}
					floor->enemyAction();
				}
			}
			else if (s == "we" && floor->myfloor[floor->player->getRow()][floor->player->getCol()-1] != NULL) {
				char c = floor->myfloor[floor->player->getRow()][floor->player->getCol()-1]->getDesc();
				if (c == 'V' || c == 'W' || c == 'N' || c == 'T' || c == 'D' || c == 'X' || c == 'M') {
					living* life = dynamic_cast<living*>(floor->myfloor[floor->player->getRow()][floor->player->getCol()-1]);
					floor->player->attack(life);
					for (int i = 0; i < 20; i++) {
						if (floor->earr[i] != NULL) {
							if (floor->earr[i]->getHP() <= 0) {
								floor->myfloor[floor->player->getRow()][floor->player->getCol()-1] = new tile(floor->earr[i]->getRow(), floor->earr[i]->getCol());
								delete floor->earr[i];
								floor->earr[i] = NULL;
							}
						}
					}
					floor->enemyAction();
				}
			}
			else if (s == "se" && floor->myfloor[floor->player->getRow()+1][floor->player->getCol()+1] != NULL) {
				char c = floor->myfloor[floor->player->getRow()+1][floor->player->getCol()+1]->getDesc();
				if (c == 'V' || c == 'W' || c == 'N' || c == 'T' || c == 'D' || c == 'X' || c == 'M') {
					living* life = dynamic_cast<living*>(floor->myfloor[floor->player->getRow()+1][floor->player->getCol()+1]);
					floor->player->attack(life);
					for (int i = 0; i < 20; i++) {
						if (floor->earr[i] != NULL) {
						if (floor->earr[i]->getHP() <= 0) {
							floor->myfloor[floor->player->getRow()+1][floor->player->getCol()+1] = new tile(floor->earr[i]->getRow(), floor->earr[i]->getCol());
							delete floor->earr[i];
							floor->earr[i] = NULL;
						}
						}
					}
					floor->enemyAction();
				}
			}
			else if (s == "sw" && floor->myfloor[floor->player->getRow()+1][floor->player->getCol()-1] != NULL) {
				char c = floor->myfloor[floor->player->getRow()+1][floor->player->getCol()-1]->getDesc();
				if (c == 'V' || c == 'W' || c == 'N' || c == 'T' || c == 'D' || c == 'X' || c == 'M') {
					living* life = dynamic_cast<living*>(floor->myfloor[floor->player->getRow()+1][floor->player->getCol()-1]);
					floor->player->attack(life);
					for (int i = 0; i < 20; i++) {
						if (floor->earr[i] != NULL) {
						if (floor->earr[i]->getHP() <= 0) {
							floor->myfloor[floor->player->getRow()+1][floor->player->getCol()-1] = new tile(floor->earr[i]->getRow(), floor->earr[i]->getCol());
							delete floor->earr[i];
							floor->earr[i] = NULL;
						}
						}
					}					
					floor->enemyAction();
				}
			}
			else if (s == "ne" && floor->myfloor[floor->player->getRow()-1][floor->player->getCol()+1] != NULL) {
				char c = floor->myfloor[floor->player->getRow()-1][floor->player->getCol()+1]->getDesc();
				if (c == 'V' || c == 'W' || c == 'N' || c == 'T' || c == 'D' || c == 'X' || c == 'M') {
					living* life = dynamic_cast<living*>(floor->myfloor[floor->player->getRow()-1][floor->player->getCol()+1]);
					floor->player->attack(life);
					for (int i = 0; i < 20; i++) {
						if (floor->earr[i] != NULL) {
						if (floor->earr[i]->getHP() <= 0) {
							floor->myfloor[floor->player->getRow()-1][floor->player->getCol()+1] = new tile(floor->earr[i]->getRow(), floor->earr[i]->getCol());
							delete floor->earr[i];
							floor->earr[i] = NULL;
						}
						}
					}
					floor->enemyAction();
				} 
			}
			else if (s == "nw" && floor->myfloor[floor->player->getRow()-1][floor->player->getCol()-1] != NULL) {
				char c = floor->myfloor[floor->player->getRow()-1][floor->player->getCol()-1]->getDesc();
				if (c == 'V' || c == 'W' || c == 'N' || c == 'T' || c == 'D' || c == 'X' || c == 'M') {
					living* life = dynamic_cast<living*>(floor->myfloor[floor->player->getRow()-1][floor->player->getCol()-1]);
					floor->player->attack(life);
					for (int i = 0; i < 20; i++) {
						if (floor->earr[i] != NULL) {
						if (floor->earr[i]->getHP() <= 0) {
							floor->myfloor[floor->player->getRow()-1][floor->player->getCol()-1] = new tile(floor->earr[i]->getRow(), floor->earr[i]->getCol());
							delete floor->earr[i];
							floor->earr[i] = NULL;
						}
						}
					}
					floor->enemyAction();
				}
			}
		}
		else if (s == "r") {
			if (floor != NULL) { delete floor; }
			floor = new board(1);
			cout << endl;
			cout << "Choose your race wisely:" << endl;
			cout << "h-human e-elf d-dwarf o-orc" << endl << endl;
			char race;
			cin >> race;
			int x, y;
			if (race == 'd') {
				x = floor->player->getRow();
				y = floor->player->getCol();
				delete floor->player;
				floor->player = new dwarf(x, y);
				floor->player->stand = new tile(x, y);
				floor->myfloor[x][y] = floor->player;
			}
			else if (race == 'e'){
				x = floor->player->getRow();
				y = floor->player->getCol();
				floor->player = NULL;
				delete floor->player;
				floor->player = new elves(x, y);
				floor->player->stand = new tile(x, y);
				floor->myfloor[x][y] = floor->player;
			}else if (race == 'o'){
				x = floor->player->getRow();
				y = floor->player->getCol();
				delete floor->player;
				floor->player = new orc(x, y);
				floor->player->stand = new tile(x, y);
				floor->myfloor[x][y] = floor->player;
			}
		}
			
		else if (s == "q") break;
		else if (s == "cheat") {
			int num;
			cin >> num;
			floor->player->updateHP(-num);
		}
		
		if (s == "inv") {
			printIt = false;
			cout << endl;
			for (int i = 0; i < 5; i++) cout << i+1 << " - " << floor->player->inv[i] << "    ";
			cout << endl << endl;
		}
		
		else if (s == "use") {
			int num; cin >> num;
			string tmp = floor->player->inv[num-1];
			if (tmp == "x" || num <= 0 || num > 5) cout << "I dont any item on that spot" << endl;
			if (tmp == "RH") {
				floor->player->updateHP(-10);
				if (floor->player->getHP() > 140) floor->player->updateHP(floor->player->getHP() - 140);
			}
			if (tmp == "PH") {
				floor->player->updateHP(10);
				if (floor->player->getHP() <= 0) floor->player = NULL;
			}
			if (tmp == "BA") floor->player->setTmpAtk(5);
			if (tmp == "BD") floor->player->setTmpDef(5);
			if (tmp == "WA") {
				floor->player->setTmpAtk(-5);
				if (floor->player->tempAtk + floor->player->getAtk() < 0) floor->player->tempAtk = -floor->player->getAtk();
			} 
			if (tmp == "WD") {
				floor->player->setTmpDef(-5);
				if (floor->player->tempDef + floor->player->getDef() < 0) floor->player->tempDef = -floor->player->getDef();
			}
			for (int i = num-1; i < 5; i++) floor->player->inv[i] = floor->player->inv[i+1];
			floor->player->invSize--; 
		}
		
		if (floor->player == NULL) {
			cout << endl;
			cout << "You lose" << endl << endl;
			cout << "Press any key to quit:" << endl;
			char z;
			cin >> z;
			break;
		}
		
			
	}	
	delete floor;
	return 0;
} 

