#ifndef _CELL__H_
#define _CELL__H_

class cell {
	int row, col;
	public :
		cell(int,int);
		virtual char getDesc() = 0;
		int getRow();
		int getCol();
		void setRow(int);
		void setCol(int);
};

#endif
