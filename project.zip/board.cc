#include <iostream>
#include "board.h"
using namespace std;

int getTheSize(int chamber) {
	if (chamber == 0) return 104;
	else if (chamber == 1) return 140;
	else if (chamber == 2) return 36;
	else if (chamber == 3) return 150;
	else return 201;
}

void fillbox (int rstart, int rend, int cstart, int cend, cell* mycell[25][79]) {
	int x = rstart;
	int y = cstart;
	while ( x <= rend ){
		while ( y <= cend ){
			mycell[x][y] = new tile(x,y);
			y ++;
		}
		x++;
		y = cstart;
	}
}

void fillarr (int from, int rstart, int rend, int cstart, int cend, cell* arr[], cell *mycell[25][79]){
	int x = from;
	for (int i = rstart; i <= rend; i++){
		for (int j = cstart; j <= cend; j++){
			arr[x] = mycell[i][j];
			x++;
		}
	}
}


// Random coordinates function
 pair <int, int> randPosn (cell* arr[], int size){ // In order to modify &
	int x = rand() % size;
	while (arr[x] == NULL) {x = rand () % size;}
	pair <int, int> Posn;
	Posn = make_pair(arr[x]->getRow(), arr[x]->getCol());
	arr[x] = NULL;
	return Posn;
}

enemies* board::generateEnemy(int row, int col) {
	int temp = rand() % 18;
	if (temp == 0 || temp == 1 || temp == 2 || temp == 3) {
		enemies* p = new werewolf(row,col);
		return p;
	}
	else if (temp == 4 || temp == 5 || temp == 6) {
		enemies* p = new vampire(row,col);
		return p;
	}
	else if (temp == 7 || temp == 8 || temp == 9 || temp == 10 || temp == 11) {
		enemies* p = new goblin(row,col);
		return p;
	}
	else if (temp == 12 || temp == 13) {
		enemies* p = new troll(row,col);
		return p;
	}
	else if (temp == 14 || temp == 15) {
		enemies* p = new phoenix(row,col);
		return p;
	}
	else {
		enemies* p = new merchant(row,col);
		return p;
	}
}

potion* generatePotion(int row, int col) {
	potion* pot = NULL;
	int temp = rand() % 6;
	if (temp == 0) pot = new potion(row,col,"RH");
	if (temp == 1) pot = new potion(row,col,"BA");
	if (temp == 2) pot = new potion(row,col,"BD");
	if (temp == 3) pot = new potion(row,col,"PH");
	if (temp == 4) pot = new potion(row,col,"WA");
	if (temp == 5) pot = new potion(row,col,"WD");
	return pot;
}
	


board::board(int num) : floorNum(num) {
	for (int i = 0; i < 25; i++){
		for (int j = 0; j < 79; j++){
			myfloor[i][j] = NULL;
		}
	}
	
	srand(time(0));
	// Initialization of cell
	fillbox(3, 6, 3, 28, myfloor); // top-left (0)
	fillbox(15, 21, 4, 24, myfloor); // bottom-left (1)
	fillbox(10, 12, 38, 49, myfloor); // middle (2)
	fillbox(19, 21, 37, 64, myfloor);
	fillbox(16, 21, 65, 75, myfloor); // bottom-right (3)
	fillbox(3, 6, 39, 60, myfloor);
	fillbox(7, 12, 61, 75, myfloor);
	fillbox(5, 6, 61, 69, myfloor);
	// Plus some manual fill out
	myfloor[3][61] = new tile(3,61);
	myfloor[4][61] = new tile(4,61);
	myfloor[6][70] = new tile(6,70);
	myfloor[6][71] = new tile(6,71);
	myfloor[7][72] = new tile(7,72);
	
	// SPAWN for matrix of tiles
	cell** arr[5];
	arr[0] = new cell*[104];
	fillarr(0, 3, 6, 3, 28, arr[0], myfloor);
	arr[1] = new cell *[140];
	fillarr(0, 15, 21, 4, 23, arr[1], myfloor);
	arr[2] = new cell*[36];
	fillarr(0, 10, 12, 38, 49, arr[2], myfloor);
	arr[3] = new cell*[3*28+6*11];
	fillarr(0, 19, 21, 37, 64, arr[3], myfloor);
	fillarr(3*28, 16, 21, 65, 75, arr[3], myfloor);
	arr[4] =  new cell*[4*22+6*15+2*9+5];
	fillarr(0, 3, 6, 39, 60, arr[4], myfloor);
	fillarr(4*22, 7, 12, 61, 75, arr[4], myfloor);
	fillarr(4*22+6*15, 5, 6, 61, 69, arr[4], myfloor);
	// Left-over cells
	arr[4][4*22+6*15+2*9] = myfloor[3][61];
	arr[4][4*22+6*15+2*9+1] = myfloor[4][61];
	arr[4][4*22+6*15+2*9+2] = myfloor[6][70];
	arr[4][4*22+6*15+2*9+3] = myfloor[6][71];
	arr[4][4*22+6*15+2*9+4] = myfloor[7][72];  
	
	// Do random for chambers
	int chamber = rand() % 5;
	pair <int, int> Posn = randPosn(arr[chamber], getTheSize(chamber));
	player = new pc(Posn.first,Posn.second, 140,20,20);
	player->stand = myfloor[Posn.first][Posn.second];
	myfloor[Posn.first][Posn.second] = player;
	
	// Spawn for stair
	int chamber2;
	while (chamber2 = rand() % 5 && chamber2 == chamber) {chamber2 = rand() % 5;}
	Posn = randPosn(arr[chamber2],getTheSize(chamber2));
	mystair = new stair(Posn.first, Posn.second); // Stair is a pointer on board and should be able to notifytd
	delete myfloor[Posn.first][Posn.second];
	myfloor[Posn.first][Posn.second] = mystair;
	
	// Spawn for potions
	for (int i = 0; i < 10; i++) {
		chamber = rand() % 5;
		Posn = randPosn(arr[chamber], getTheSize(chamber));
		while (myfloor[Posn.first][Posn.second]->getDesc() != '.') Posn = randPosn(arr[chamber],getTheSize(chamber));
		potion* pot = generatePotion(Posn.first,Posn.second);
		delete myfloor[Posn.first][Posn.second];
		myfloor[Posn.first][Posn.second] = pot;
	}
	
	// Spawn for enemies
	for (int i=0; i < 20; i++){
		chamber = rand() % 5;
		Posn = randPosn(arr[chamber],getTheSize(chamber));
		while (myfloor[Posn.first][Posn.second]->getDesc() != '.') Posn = randPosn(arr[chamber],getTheSize(chamber));
		earr[i] = generateEnemy(Posn.first, Posn.second); // Need to add different classes
		earr[i]->stand = myfloor[Posn.first][Posn.second];
		myfloor[Posn.first][Posn.second] = earr[i];
	}  
	
	for (int i = 0; i < 20; i++) {
		earr[i]->updateDistHor(earr[i]->getRow() - player->getRow());
		earr[i]->updateDistVer(earr[i]->getCol() - player->getCol());
	}
	
	// Doorways
	myfloor[4][29] = new doorway(4,29);
	myfloor[4][38] = new doorway(4,38);
	myfloor[7][13] = new doorway(7,13);
	myfloor[14][13] = new doorway(14,13);
	myfloor[20][25] = new doorway(20,25);
	myfloor[20][36] = new doorway(20,36);
	myfloor[7][43] = new doorway(7,43);
	myfloor[9][43] = new doorway(9,43);
	myfloor[13][43] = new doorway(13,43);
	myfloor[18][43] = new doorway(18,43);
	myfloor[13][69] = new doorway(13,69);
	myfloor[15][69] = new doorway(15,69);
	myfloor[11][60] = new doorway(11, 60);
	
	// Passages
	for (int i = 8; i < 14; i++)
		myfloor[i][13] = new passage(i,13);
	for (int i = 9; i < 20; i++)
		myfloor[i][31] = new passage(i,31);
	for (int i = 11; i < 17; i++)
		myfloor[i][54] = new passage(i,54);
	for (int i = 14; i < 31; i++)
		myfloor[11][i] = new passage(11,i);
	for (int i = 30; i < 38; i++)
		myfloor[4][i] = new passage(4,i);
	for (int i = 31; i < 44; i++)
		myfloor[8][i] = new passage(8,i);
	for (int i = 32; i < 54; i++)
		myfloor[16][i] = new passage(16,i);
	for (int i = 55; i < 60; i++)
		myfloor[11][i] = new passage(11,i);
	for (int i = 26; i < 36; i++)
		myfloor[20][i] = new passage(20,i);
	for (int i = 5; i < 8; i++)
		myfloor[i][33] = new passage(i, 33);
	//Some separate passage
	myfloor[14][69] = new passage(14, 69);
	myfloor[14][43] = new passage(14, 43);
	myfloor[15][43] = new passage(15, 43);
	myfloor[17][43] = new passage(17, 43);
	
	// delete arr
	for (int i = 0; i < 5; i++)
		delete [] arr[i];
}

board::~board() {
	for (int i = 0; i < 25; i++){
		for (int j = 0; j < 79; j++){
			if (myfloor[i][j] != NULL) {
				delete myfloor[i][j];
			}
			myfloor[i][j] = NULL;
		}
	}
}

void board::swapCell(living* first, cell* second) {
	int temp1,temp2;
	cell* temp;
	if (first->getDesc() == '@') {
		if (second->getDesc() == '.' || second->getDesc() == '+' || second->getDesc() == '#' || second-> getDesc() == '/' || second->getDesc() == 'P') {
			temp = first->stand;
			first->stand = second;
			myfloor[first->getRow()][first->getCol()] = temp;
			myfloor[second->getRow()][second->getCol()] = player; 
			
			temp1 = first->getRow();
			temp2 = first->getCol();
			first->setRow(second->getRow());
			first->setCol(second->getCol());
			myfloor[temp1][temp2]->setRow(temp1);
			myfloor[temp1][temp2]->setCol(temp2);
			
			for (int i = 0; i < 20; i++) {
				if (earr[i] != NULL && player != NULL) {
					earr[i]->updateDistHor(earr[i]->getRow() - player->getRow());
					earr[i]->updateDistVer(earr[i]->getCol() - player->getCol());
				}
			}	
		}
	}
	else {
		if (second->getDesc() == '.') {
			temp = first->stand;
			first->stand = second;
			myfloor[first->getRow()][first->getCol()] = temp;
			myfloor[second->getRow()][second->getCol()] = first; 
			temp1 = first->getRow();
			temp2 = first->getCol();
			first->setRow(second->getRow());
			first->setCol(second->getCol());
			myfloor[temp1][temp2]->setRow(temp1);
			myfloor[temp1][temp2]->setCol(temp2);
			for (int i = 0; i < 20; i++) {
				if (earr[i] != NULL && player != NULL) {
					earr[i]->updateDistHor(earr[i]->getRow() - player->getRow());
					earr[i]->updateDistVer(earr[i]->getCol() - player->getCol());
				}
			}
		}
	}
}
			
	

void board::enemyAction() {
	for (int i = 0; i < 20; i++) {
		if (earr[i] != NULL) {
			if (abs(earr[i]->getDistHor()) < 2 && abs(earr[i]->getDistVer()) < 2 && player != NULL) {
				earr[i]->attack(player);
				if (player->getHP() <= 0) {
					delete player;
					player = NULL;
				}
			}
			else {
				int x = rand() % 3;
				x -= 1;
				int y = rand() % 3;
				y -= 1;
				if (myfloor[earr[i]->getRow()+x][earr[i]->getCol()+y] != NULL) 
				swapCell(earr[i],myfloor[earr[i]->getRow()+x][earr[i]->getCol()+y]);
			}
		}
	}
}
			

void board::printboard(){
	for (int i = 0; i < 25; i++) {
		for (int j = 0; j < 79; j++) {
			if (myfloor[i][j] != NULL){
				cout << myfloor[i][j]->getDesc();
			}else if((i == 0 || i == 24) && ( j != 0 && j!= 78)){
				cout << '-';
			}else if(j == 0 || j == 78){
				cout << '|';
			}else{
				// Boarder for chambers or space
				if (i == 2 && ((j >= 3 && j <= 28)||(j >= 39 && j <= 61))){
					cout << '-';
				}else if (i == 7 && (j >= 3 && j <= 28)){
					cout << '-';
				}else if ((j == 2 || j == 29) && (i >=2 && i <= 7)){
					cout << '|';
				}else if ((i == 14 || i == 22) && (j >= 4 && j <= 24)){
					cout << '-';
				}else if ((j == 3 || j == 25) && (i >= 14 && i <= 22)){
					cout << '|';
				// For the chamber in middle
				 }else if ((i == 9 || i == 13) && (j >= 38 && j <= 49)){
					cout << '-';
				}else if ((j == 37 || j == 50) && (i >= 9 && i <= 13)){
					cout << '|';
				}else if (j == 38 && (i >= 2 && i <= 7)){
					cout << '|';
				}else if(i == 13 && (j >= 61 && j <= 75)){
					cout << '-';
				}else if((j == 60 || j == 76) && (i >= 6 && i<= 13)){
					cout << '|';
				}else if((j == 73 && (i == 5 || i == 6)) || (j == 70 && (i == 4 || i == 5))){
					cout << '|';
				}else if(j == 62 && (i >= 2 && i <= 4)){
					cout << '|';
				}else if(i == 7 && (j >= 39 && j <= 59)){
					cout << '-';
				}else if(i == 4 && (j >= 63 && j <= 69)){
					cout << '-';
				}else if((i == 5 && (j == 71 || j == 72))||(i == 6 && (j == 74 || j == 75))){
					cout << '-';
				}else if(j == 36 && (i >= 18 && i <= 22)){
					cout << '|';
				}else if((j == 76 || j == 64) && (i >= 15 && i <= 22)){
					if ((j == 64 && i == 22)) {cout << '-';}
					else {cout << '|';}
				}else if((i == 22 || i == 18) && (j >= 37 && j <= 75)){
					cout << '-';
				}else if(i == 15 && (j <= 75 && j >= 65)){
					cout << '-';
				}else{
					cout << ' ';
				}
			}
		}
		cout << endl;
	}
	
	// For prompt:
	cout << "Race: " << player->getRace() << " Gold: " << player->getGold();
	cout << "                                                  ";
	cout << "Floor: " << floorNum << endl;
	cout << "HP: " << player->getHP() << endl;
	cout << "Atk: " << player->getAtk()+player->gettempAtk() << endl;
	cout << "Def: " << player->getDef()+player->gettempDef() << endl;
	cout << "Action: ";
}

