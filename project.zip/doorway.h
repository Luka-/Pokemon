#ifndef _DOORWAY__H_
#define _DOORWAY__H_

#include <iostream>
#include <string>
#include "cell.h"

class doorway : public cell {
	int flag;
	public :
		doorway(int,int);
		char getDesc();
};

#endif
