#include <iostream>
#include <string>
#include "doorway.h"
using namespace std;

doorway::doorway(int row,int col) : cell(row,col) {
	flag = 0;
}

char doorway::getDesc() {
	return '+';
}
