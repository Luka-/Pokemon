#include <iostream>
#include "human.h"
#include <string>
using namespace std;

human::human(int row, int col) : pc (row, col, 140, 20, 20) {}


void human::updateGold(int num) {
	gold += num;
}

void human::setTmpAtk(int num)	{
	tempAtk += num;
}

void human::setTmpDef(int num) {
	tempDef	+= num;
}		

string human::getRace() {
	return "Human";
}
