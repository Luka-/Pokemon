#include <iostream>
#include "troll.h"
using namespace std;

troll::troll(int row, int col) : enemies(row,col,120,25,15) {}

char troll::getDesc() {
	return 'T';
}
