#include <iostream>
#include "pc.h"
#include <string>
using namespace std;

pc::pc(int row, int col, int hp, int atk, int def) : living(row,col,hp,atk,def) {
	gold = 0;
	tempAtk = 0;
	tempDef = 0;
	mer = false;
	inv[0] = "x";
	inv[1] = "x";
	inv[2] = "x";
	inv[3] = "x";
	inv[4] = "x";
	inv[5] = "x";
	invSize = 0;
}

char pc::getDesc() {
	return '@';
}

int pc::getGold() {
	return gold;
}

int pc::gettempAtk(){
	return tempAtk;
}

int pc::gettempDef(){
	return tempDef;
}

void pc::updateGold(int x){
	gold += x;
}

void pc::setTmpAtk(int x){
	tempAtk += x;
}
void pc::setTmpDef(int x){
	tempDef += x;
}

string pc::getRace() {
	return "Human";
}
