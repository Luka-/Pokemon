#include <iostream>
#include "merchant.h"
using namespace std;

merchant::merchant(int row, int col) : enemies(row,col,30,70,5) {}

char merchant::getDesc() {
	return 'M';
}
