#ifndef __BORAD_H__
#define __BORAD_H__
#include <iostream>
#include <string>
#include "tile.h"
#include "doorway.h"
#include "passage.h"
#include <cstdlib>
#include <utility>
#include "pc.h"
#include "stair.h"
#include "living.h"
#include "enemies.h"
#include "werewolf.h"
#include "vampire.h"
#include "goblin.h"
#include "troll.h"
#include "phoenix.h"
#include "merchant.h"
#include "potion.h"


class board {
	public :
		int floorNum;
		cell* myfloor[25][79];  // All floor tiles
		pc *player;  // Player character
		enemies *earr[20];  //Array of enemies
		stair* mystair;
		// hoard as well
		board(int);
		~board();
		enemies* generateEnemy(int,int);
		void enemyAction();
		void swapCell(living*,cell*);
		void printboard();
};

#endif
