#include <iostream>
#include "vampire.h"
using namespace std;

vampire::vampire(int row, int col) : enemies(row,col,50,25,25) {}

char vampire::getDesc() {
	return 'V';
}
