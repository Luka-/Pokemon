#include <iostream>
#include <string>
#include <cmath>
#include "living.h"
#include "tile.h"
#include "doorway.h"
#include "passage.h"
#include <cstdlib>
#include "merchant.h"
#include "pc.h"
using namespace std;

living::living(int row, int col, int HP,int Atk,int Def) : cell(row,col), HP(HP), Atk(Atk), Def(Def) {
	stand = NULL;
}

int living::getHP () {
	return HP;
}

void living::updateHP (int num) {
	HP -= num;
}

int living::getDef () {
	return Def;
}
	
int living::getAtk() {
	return Atk;
}

void living::attack(living* target) {
	int n = rand() % 2;
	if (target->getDesc() == 'M') {
		pc* temp = dynamic_cast<pc*>(this);
		temp->mer = true;
	}
	if (this->getDesc() == '@') {
		pc* temp = dynamic_cast<pc*>(this); 
		target->updateHP(ceil(((float)(100*(Atk+temp->gettempAtk())))/((float)(100+target->getDef()))));
	}
	else if (n == 0) {
		pc* temp = dynamic_cast<pc*>(target);
		if (this->getDesc() != 'M')  target->updateHP(ceil(((float)(100*Atk))/((float)(100+target->getDef()+temp->gettempDef()))));
		else {
			pc* temp = dynamic_cast<pc*>(target);
			if (temp->mer) target->updateHP(ceil(((float)(100*Atk))/((float)(100+target->getDef()+temp->gettempDef()))));
		}
	}
}
