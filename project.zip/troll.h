#ifndef _TROLL__H_
#define _TROLL__H_
#include <iostream>
#include "enemies.h"

class troll : public enemies {
	public :
		troll(int,int);
		char getDesc();
};

#endif
