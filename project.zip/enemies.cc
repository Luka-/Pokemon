#include <iostream>
#include <string>
#include <cmath>
#include "enemies.h"
using namespace std;

enemies::enemies(int row, int col, int HP, int Atk, int Def) : living(row,col,HP,Atk,Def) {
	distHor = 0;
	distVer = 0;
	tempAtk = 0;
	tempDef = 0;
} 

int enemies::getDistHor() {
	return distHor;
}

int enemies::getDistVer() {
	return distVer;
}

void enemies::updateDistHor(int num) {
	distHor = num;
}

void enemies::updateDistVer(int num) {
	distVer = num;
}
