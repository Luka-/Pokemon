#include "elves.h"
#include <cmath>
#include <string>
using namespace std;

elves::elves(int row, int col) : pc(row, col, 140, 30, 10) {}

void elves::updateGold(int num) {
	gold += num;
}

void elves::setTmpAtk(int num)	{
	tempAtk += abs(num);
}

void elves::setTmpDef(int num) {
	tempDef	+= abs(num);
}

string elves::getRace() {
	return "Elf";
}
