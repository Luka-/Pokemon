#include <iostream>
#include <string>
#include "cell.h"
using namespace std;

cell::cell (int row, int col) : row(row), col(col) {}

int cell::getRow() {
	return row;
}

int cell::getCol() {
	return col;
}

void cell::setRow(int num) {
	row = num;
}

void cell::setCol(int num) {
	col = num;
}
