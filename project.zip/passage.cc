#include <iostream>
#include <string>
#include "passage.h"
using namespace std;

passage::passage (int row,int col) : cell(row,col) {
	flag = 0;
}

char passage::getDesc() {
	return '#';
}
