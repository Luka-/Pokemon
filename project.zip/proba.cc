#include <iostream>
using namespace std;

int main () {
	int a[10];
	int x = 3;
	int* p = &x;
	a = p;
	cout << a[5] << endl;
	return 0;
}
