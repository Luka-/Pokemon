#include "dwarf.h"
#include <string>
using namespace std;

dwarf::dwarf (int row, int col) : pc (row, col, 100, 20, 30) {}

void dwarf::updateGold(int num){
	gold += num*2;
}


void dwarf::setTmpAtk(int num)	{
	tempAtk += num;
}

void dwarf::setTmpDef(int num) {
	tempDef	+= num;
}		

string dwarf::getRace() {
	return "Dwarf";
}
