#ifndef __HUMAN_H__
#define __HUMAN_H__
#include <iostream>
#include "pc.h"
#include "living.h"
#include <string>

class human : public pc {
	public:
	human(int, int);
	void updateGold(int);
	void setTmpAtk(int);
	void setTmpDef(int);
	std::string getRace();
};

#endif
